import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-app.js";
import { 
  getFirestore, 
  collection, 
  addDoc, 
  serverTimestamp, 
  onSnapshot, 
  doc, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy 
} from "https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  onAuthStateChanged, 
  signOut 
} from "https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDjiIR9rPT1oSKxyvukvUWqvjUr__ufiW4",
    authDomain: "todo-app-acb73.firebaseapp.com",
    projectId: "todo-app-acb73",
    storageBucket: "todo-app-acb73.appspot.com",
    messagingSenderId: "1006390146421",
    appId: "1:1006390146421:web:d4401c581adb40d88a8f3c",
    measurementId: "G-D2RDZBV8ZC"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// DOM Elements
const todoForm = document.getElementById('todo-form');
const todoInput = document.getElementById('todo-input');
const todoList = document.getElementById('todo-list');
const loginForm = document.getElementById('login-form');
const userInfo = document.getElementById('user-info');
const loginEmail = document.getElementById('login-email');
const loginPassword = document.getElementById('login-password');
const loginBtn = document.getElementById('login-btn');
const signupBtn = document.getElementById('signup-btn');
const logoutBtn = document.getElementById('logout-btn');
const userEmail = document.getElementById('user-email');
const appContainer = document.getElementById('app-container');
const authContainer = document.getElementById('auth-container');
const errorMessage = document.getElementById('error-message'); // Add this element to your HTML

// Initialize UI
function initUI() {
    authContainer.style.display = 'none';
    appContainer.style.display = 'none';
    userInfo.style.display = 'none';
    loginForm.style.display = 'none';
}

initUI();

// Add a new todo
todoForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const todoText = todoInput.value.trim();
    if (todoText !== '') {
        try {
            await addDoc(collection(db, 'todos'), {
                text: todoText,
                completed: false,
                createdAt: serverTimestamp()
            });
            todoInput.value = '';
        } catch (error) {
            console.error("Error adding document: ", error);
        }
    }
});

// Real-time listener for todos
function setupTodoListener() {
    onSnapshot(
        query(collection(db, 'todos'), orderBy('createdAt')), 
        (snapshot) => {
            todoList.innerHTML = ''; // Clear existing todos
            snapshot.forEach(doc => {
                renderTodos(doc);
            });
        },
        (error) => {
            console.error("Error getting todos: ", error);
        }
    );
}

// Render todos
function renderTodos(doc) {
    const li = document.createElement('li');
    li.className = 'list-group-item';
    li.setAttribute('data-id', doc.id);

    const todoText = document.createElement('span');
    todoText.textContent = doc.data().text;
    if (doc.data().completed) {
        todoText.classList.add('completed');
    }

    const buttonsDiv = document.createElement('div');
    
    const completeButton = document.createElement('button');
    completeButton.className = 'btn btn-success btn-sm me-2';
    completeButton.textContent = '✓';
    completeButton.addEventListener('click', async () => {
        await updateDoc(doc(db, 'todos', doc.id), {
            completed: !doc.data().completed
        });
    });

    const deleteButton = document.createElement('button');
    deleteButton.className = 'btn btn-danger btn-sm';
    deleteButton.textContent = '✕';
    deleteButton.addEventListener('click', async () => {
        await deleteDoc(doc(db, 'todos', doc.id));
    });

    buttonsDiv.appendChild(completeButton);
    buttonsDiv.appendChild(deleteButton);
    li.appendChild(todoText);
    li.appendChild(buttonsDiv);
    todoList.appendChild(li);
}

// Authentication state listener
onAuthStateChanged(auth, user => {
    if (user) {
        // User is signed in
        authContainer.style.display = 'none';
        appContainer.style.display = 'block';
        userEmail.textContent = user.email;
        userInfo.style.display = 'block';
        loginForm.style.display = 'none';
        errorMessage.textContent = '';
        
        // Set up todo listener only when user is authenticated
        setupTodoListener();
    } else {
        // No user is signed in
        authContainer.style.display = 'block';
        appContainer.style.display = 'none';
        userInfo.style.display = 'none';
        loginForm.style.display = 'block';
    }
});

// Login event
loginBtn?.addEventListener('click', async (e) => {
    e.preventDefault();
    const email = loginEmail.value;
    const password = loginPassword.value;
    
    if (!email || !password) {
        errorMessage.textContent = 'Please enter both email and password';
        return;
    }

    try {
        await signInWithEmailAndPassword(auth, email, password);
        // Clear form fields
        loginEmail.value = '';
        loginPassword.value = '';
    } catch (error) {
        console.error("Login error: ", error);
        errorMessage.textContent = error.message;
    }
});

// Signup event
signupBtn?.addEventListener('click', async (e) => {
    e.preventDefault();
    const email = loginEmail.value;
    const password = loginPassword.value;
    
    if (!email || !password) {
        errorMessage.textContent = 'Please enter both email and password';
        return;
    }

    try {
        await createUserWithEmailAndPassword(auth, email, password);
        // Clear form fields
        loginEmail.value = '';
        loginPassword.value = '';
    } catch (error) {
        console.error("Signup error: ", error);
        errorMessage.textContent = error.message;
    }
});

// Logout event
logoutBtn?.addEventListener('click', async () => {
    try {
        await signOut(auth);
    } catch (error) {
        console.error("Logout error: ", error);
        errorMessage.textContent = error.message;
    }
});